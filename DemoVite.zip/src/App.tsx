import "./App.css";
import { RouterProvider, createBrowserRouter } from "react-router-dom";
import RootLayout from "./components/Layout/RootLayout";
import OrderHistory from "./components/Ecommerce/OrderHistory";
import OrderSummary from "./components/Ecommerce/OrderSummary";
import CheckoutForm from "./components/Ecommerce/CheckoutForm";
import NewProduct from "./components/Ecommerce/NewProduct";
import ShoppingCart from "./components/Ecommerce/ShoppingCart";
import ProductOverview from "./components/Ecommerce/ProductOverview";
import ProductList from "./components/Ecommerce/ProductList";
import Dashboard from "./components/Dashboard";
import Customers from "./components/Customers";

const router = createBrowserRouter([
  {
    path: "/",
    element: <RootLayout />,
    children: [
      {
        path: "/dashboard",
        element: <Dashboard />,
      },
    ],
  },
  {
    path: "/e-commerce",
    element: <RootLayout />,
    children: [
      {
        path: "product-overview",
        element: <ProductOverview />,
      },
      {
        path: "product-list",
        element: <ProductList />,
      },
      {
        path: "new-product",
        element: <NewProduct />,
      },
      {
        path: "shopping-cart",
        element: <ShoppingCart />,
      },
      {
        path: "checkout-form",
        element: <CheckoutForm />,
      },
      {
        path: "order-history",
        element: <OrderHistory />,
      },
      {
        path: "order-summary",
        element: <OrderSummary />,
      },
    ],
  },
  {
    path: "/customer-contact",
    element: <RootLayout />,
    children: [
      {
        path: "customer",
        element: <Customers />,
      },
    ],
  },
]);

function App() {
  return (
    <>
      <RouterProvider router={router} />
    </>
  );
}

export default App;
